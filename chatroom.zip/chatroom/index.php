<?php 
  session_start();
  include 'include/connect.php';
 ?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>chatroom</title>
  <link rel="stylesheet" href="css/style.css">

</head>
<body>
<div class="content">
       <div class="poster">
     <img id="backbg" src="bg.jpg">
   </div>
  <div class="wrapper">
<div class="container">
    <div class="tabs">
      <ul>
        <li class="sign_in_li">Sign in</li>
        <li class="sign_up_li">Sign up</li>
      </ul>
    </div>
  <p class="error"></p>
    <div class="sign_in">
      <form action=""  method="post" id="sign_in">
      <div class="input_field">
        <input type="email" id="Lemail" name="Lemail" placeholder="E-mail" class="input">
      </div>
      <div class="input_field">
        <input type="password" id="Lpwd" name="Lpwd" placeholder="Password" class="input">
      </div>
      <button class="btn" type="submit" id="signIn">Sign in</button>
    </form>
    </div>
    
    
    <div class="sign_up">
      <form action="" method="post" id="sign_up">
      <div class="input_field">
        <input type="text" id="username" name="username" placeholder="Username" class="input">
      </div>
      <div class="input_field">
        <input type="email" id="email" name="email" placeholder="E-mail" class="input">
      </div>
      <div class="input_field">
        <input type="password" id="pwd" name="pwd" placeholder="Password" class="input">
      <button class="btn" type="submit" id="signUp">Sign up</button>
      </form>
    </div>
</div>
</div>

</div> 

<!-- partial -->
<script src='js/jquery.min.js'></script>  
<script  src="js/validate.min.js"></script>
<script  src="js/additional-methods.min.js"></script>
<script  src="js/script.js"></script>
<script type="text/javascript">
 
</script>
</body>
</html>
