<?php 
session_start();
include 'connect.php';
/*===================[login]=======================*/
if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$email = valid($_POST['Lemail']);
	 	$chekEmail = $db->prepare("SELECT email FROM users WHERE email= :email LIMIT 1");
	    $chekEmail->bindParam(':email', $email, PDO::PARAM_STR);
	    $chekEmail->execute();
	    $num = $chekEmail->rowCount();
	    if ($num > 0) {
	    	$pwd = valid($_POST['Lpwd']);
	    	$chekPwd = $db->prepare("SELECT pwd FROM users WHERE email= :email");
		    $chekPwd->bindParam(':email', $email, PDO::PARAM_STR);
		    $chekPwd->execute();
		    while ($row = $chekPwd->fetch(PDO::FETCH_ASSOC)) {
		        $Password = $row['pwd'];
		    }
		    if (password_verify($pwd, $Password)) {
				$query = $db->prepare("SELECT * FROM users WHERE email= :email AND pwd= :Password");
				$query->bindParam(':email', $email, PDO::PARAM_STR);
				$query->bindParam(':Password', $Password, PDO::PARAM_STR);
				$query->execute();
				$num = $query->rowCount();
				    if($num == 0){
				        echo 'Email or password incorrect';
				    }else{
				    	while($row_fetch = $query->fetch(PDO::FETCH_ASSOC)){
				    		$_email = $row_fetch['email'];
							$_token = $row_fetch['token'];
							$_username = $row_fetch['username'];
							$_profile = $row_fetch['profile'];
				    	}
				        $_SESSION['username'] = $_username;
						$_SESSION['email'] = $_email;
						$_SESSION['token'] = $_token;
						$_SESSION['profile'] = $_profile;
				        echo "access";
				    }

		    }else{
		    	echo 'Email or password incorrect';
		    }
	    }else{
	    	echo 'Email or password incorrect';
	    }
	}
	function valid($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
 ?>