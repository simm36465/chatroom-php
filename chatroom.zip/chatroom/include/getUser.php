<?php 
session_start();
include 'connect.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$id = htmlspecialchars($_POST['id']);
	$data = $db->prepare("SELECT * FROM users WHERE token=:id");
	$data->bindParam(":id", $id, PDO::PARAM_STR);
	$data->execute();
	 while ($row = $data->fetch(PDO::FETCH_ASSOC)) {
	 	echo 
	 	'
			<div class="chat-header">
                <span class="avatar avatar-sm status status-offline mr-3 bg-info rounded-circle">
                  <img src="'.$row['profile'].'" style="width: 44px;border-radius:50%;border: 2px solid #fff;">
                </span>
                <div class="mr-auto" data-uid="'.$row['token'].'" id="Cuser">
                  <h3 class="mb-2 fs-xxs lh-sm">'.$row['username'].'</h3>
                  <p class="lh-sm">'.$row['email'].'</p>
                </div>

              </div>
              <div class="chat-body">

              </div>



	 	';
	 }
}


 ?>