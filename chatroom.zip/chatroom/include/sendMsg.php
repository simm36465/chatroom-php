<?php
session_start();
include 'connect.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$m_from = $_SESSION['token'];
$m_to = filter_var(htmlentities($_POST['id']),FILTER_SANITIZE_NUMBER_INT);
$message = trim(filter_var(htmlentities($_POST['MSG']),FILTER_SANITIZE_STRING));	
$m_id = rand(0,999999999)+time();
$m_at = time();
$m_vu="0";
$query = $db->prepare("INSERT INTO chat (m_id, m_from, m_to, m_at, message,  m_vu) VALUES(:m_id, :m_from, :m_to, :m_at, :message, :m_vu)");
$query->bindParam(':m_id',$m_id,PDO::PARAM_INT);
$query->bindParam(':m_from',$m_from,PDO::PARAM_INT);
$query->bindParam(':m_to',$m_to,PDO::PARAM_INT);
$query->bindParam(':m_at',$m_at,PDO::PARAM_INT);
$query->bindParam(':message',$message,PDO::PARAM_STR);
$query->bindParam(':m_vu',$m_vu,PDO::PARAM_INT);
$query->execute();
if (!$query) {
    echo "error";
}
}
 ?>