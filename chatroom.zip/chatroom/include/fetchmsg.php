<?php 
session_start();
include 'connect.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$uid = filter_var(htmlentities($_POST['id']),FILTER_SANITIZE_NUMBER_INT);
	$current_id = $_SESSION['token'];
// m_seen set to seen
$vu = "1";
$seenUpdate = $db->prepare("UPDATE chat SET m_vu = :vu WHERE m_from=:uid AND m_to=:current_id");
$seenUpdate->bindParam(':vu',$vu,PDO::PARAM_INT);
$seenUpdate->bindParam(':current_id',$current_id,PDO::PARAM_INT);
$seenUpdate->bindParam(':uid',$uid,PDO::PARAM_INT);
$seenUpdate->execute();
// select messages and fetch
$getMsgs = $db->prepare("SELECT * FROM chat WHERE (m_from = :current_id AND m_to = :uid) OR (m_from = :uid AND m_to = :current_id)");
$getMsgs->bindParam(':current_id',$current_id,PDO::PARAM_INT);
$getMsgs->bindParam(':uid',$uid,PDO::PARAM_INT);
$getMsgs->execute();
$getMsgsCout = $getMsgs->rowCount();
if ($getMsgsCout > 0) {
while ($msgs_row = $getMsgs->fetch(PDO::FETCH_ASSOC)) {
	if ($msgs_row['m_from'] == $current_id) {
		echo 
		'<div class="d-flex align-items-end justify-content-end mb-5">
                    <span class="avatar avatar-sm order-2 ml-3 bg-primary rounded-circle">
			<img src="'.$_SESSION['profile'].'" style="width: 40px;border-radius:50%;">
                    </span>
                    <div class="order-1">
                      <div class="card mb-3 text-white bg-primary">
                        <p>'.$msgs_row['message'].'</p>
                      </div>
                    </div>
                  </div>';
	}elseif ($msgs_row['m_to'] == $current_id) {
		echo 
		'<div class="d-flex align-items-end mb-5">
                    <span class="avatar avatar-sm mr-3 bg-info rounded-circle">
<img src="'.$_SESSION['profile'].'" style="width: 40px;border-radius:50%;">
                    </span>
                    <div>
                      <div class="card mb-3">
                        <p>'.$msgs_row['message'].'</p>
                      </div>
                    </div>
                  </div>';
	}else {
		echo  '  
	<div class="alert alert-info">Say hello !</div>
';
	}
}
}
}

 ?>