<?php 

session_start();
include 'connect.php';

/*===========================[signup]===========================*/
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	 $username = valid($_POST['username']);
	 $email = valid($_POST['email']);
	 $pwd = valid($_POST['pwd']);
	 $check_username = "SELECT * FROM users WHERE username=:username";
	 $exist_username = $db->prepare($check_username);
	 $exist_username->bindParam(':username', $username, PDO::PARAM_STR);
	 $exist_username->execute();
	 $num_row_username= $exist_username->rowCount();
	 if ($num_row_username > 0) {
	 	array_push($Err, "username is already used");
	 }
	$check_email = "SELECT * FROM users WHERE email=:email";
	 $exist_email = $db->prepare($check_email);
	 $exist_email->bindParam(':email', $email, PDO::PARAM_STR);
	 $exist_email->execute();
	 $num_row_email= $exist_email->rowCount();
	 if ($num_row_email > 0) {
	 	array_push($Err, "Email is already used");
	 }
	 $options = ['cost' => 12,];
	 $pwd = password_hash($pwd, PASSWORD_BCRYPT, $options);
	 $token = rand(0, 999999)+ rand(0, time());
	 $profile = "image/profile.jpg";
	 $data = "INSERT INTO users(token, username, email, pwd, profile) VALUES (:token, :username, :email, :pwd, :profile)";
	 $query = $db->prepare($data);
	$query->bindParam(':token', $token, PDO::PARAM_INT);
	$query->bindParam(':email', $email, PDO::PARAM_STR);
	$query->bindParam(':username', $username, PDO::PARAM_STR);
	$query->bindParam(':pwd', $pwd, PDO::PARAM_STR);
	$query->bindParam(':profile', $profile, PDO::PARAM_STR);
	$query->execute();
	echo 'registred';
}
function valid($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
 ?>