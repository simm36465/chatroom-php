<?php
session_start();
include "include/connect.php";
// destroy session and redirect to main page
session_destroy();
session_unset();
header("location: index");
exit;
?>