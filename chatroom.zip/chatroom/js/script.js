  
  $(".sign_up").hide();
$(".sign_in_li").addClass("active");
var bg = document.getElementById("backbg");

$(".sign_up_li").click(function(){
  $(this).addClass("active");
  $(".sign_in_li").removeClass("active");
  $(".sign_up").show();
  bg.src = "bg1.jpg";
  $(".sign_in").hide();
})

$(".sign_in_li").click(function(){
  $(this).addClass("active");
  $(".sign_up_li").removeClass("active");
  $(".sign_in").show();
  bg.src = "bg.jpg";
  $(".sign_up").hide();
})

 /*****************/

      $("#sign_in").validate({
        errorClass: "state-error",
        validClass: "has-success",
        errorElement: "p",
        rules: {
            Lemail: {
                required: true,
                email: true
            },
            Lpwd: {
                required: true,
            }
        },
    });
  $('#sign_in').on('submit',function(e) {
    e.preventDefault();
    if ($(this).valid() == true) {
      $.ajax({
                type: 'POST',
                url: 'include/login.php',
                data: $(this).serializeArray(),
                beforeSend: function () {
                    
                },
                success: function (data) {
                  if (data == "access") {
                    setTimeout(' window.location.href = "home"; ',2000);
                  } else {
                   $(".error").html(data);
                  }
                },
                error: function (err) {
                    alert(err);
                }
            });
    }
    
    });

/*****************************/
      $("#sign_up").validate({
        errorClass: "state-error",
        validClass: "has-success",
        errorElement: "p",
        rules: {
          username: {
             required: true,
             minlength: 3
          },
            email: {
                required: true,
                email: true
            },
            pwd: {
                required: true,
                minlength: 5
            }
        },
    });
  $('#sign_up').on('submit',function(e) {
    e.preventDefault();
    if ($(this).valid() == true) {
                $.ajax({
                type: 'POST',
                url: 'include/signup.php',
                data: $(this).serializeArray(),
                beforeSend: function () {
                    
                },
                success: function (data) {
                  if (data == "registred") {
                    location.reload();
                  } else {
                    $(".error").html(data);
                  }
                },
                error: function (err) {
                    alert(err);
                }
            });
    }
    
    });






   
